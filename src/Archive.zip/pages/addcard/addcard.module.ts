import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddcardPage } from './addcard';

@NgModule({
  declarations: [
    AddcardPage,
  ],
  imports: [
    IonicPageModule.forChild(AddcardPage),
  ],
})
export class AddcardPageModule {}
