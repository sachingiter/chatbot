import { Component,ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams,Content, ModalController } from 'ionic-angular';
import { UserservicesProvider } from '../../providers/userservices/userservices';
import * as firebase from 'Firebase';
import { CallNumber } from '@ionic-native/call-number';


/**
 * Generated class for the DashboardPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-dashboard',
  templateUrl: 'dashboard.html',
})
export class DashboardPage {
  @ViewChild(Content) content: Content;

  compose:any;
  messages:any = [];
  chats:any;

  rooms = [];
  ref = firebase.database().ref('chatrooms/');
  i = 10;
  dbName:any;

  fromStation:any;
  toStation:any;
  fromicsId:any;
  toicsId:any;

  openForm:boolean = false;

  constructor(public navCtrl: NavController, public navParams: NavParams, public userServices:UserservicesProvider, private callNumber: CallNumber,
    public modalCtrl:ModalController) {
    // this.ref.on('value', resp => {
    //   this.rooms = [];
    //   this.rooms = snapshotToArray(resp);
    // });
  }

  ionViewDidEnter() {
    this.dbName = this.userServices.getUserName().replace(" ", "_")+this.userServices.getUserId();
    this.loadOldChat();
  }

  loadOldChat(){
    firebase.database().ref('chatrooms/'+this.dbName).on('value', resp => {
      this.messages = snapshotToArray(resp);
      // console.log(this.messages);
      setTimeout( ()=>{
        this.content.scrollToBottom();
      },300);
    });
    this.i ++;
  }

  createChat(from,message,restaurants = null){
    // let newData = this.ref.push();
    // newData.set({
    //   roomname:"praveen"
    // });
    let dbName = this.userServices.getUserName().replace(" ", "_")+this.userServices.getUserId();
    let joinData = firebase.database().ref('chatrooms/'+this.dbName).push();
    joinData.set({
      from : from,
      message : message,
      restaurants : (restaurants)?restaurants:'',
      time:Date()
    });

    
  }

  clearSession(){
    let msg = {
      message:"new",
      from:'user'
    }
    this.messages.push(msg);
    setTimeout( ()=>{
      this.content.scrollToBottom();
    },300);

    let dataToSend = "new"; 
    this.compose = null;

    this.userServices.chat(dataToSend).then( data=> {
      console.log(data);
      let fromsms = {
        message : data['message'],
        from : 'bot',
        action : data['action'],
        restaurants : data['restaurants']
      }
      this.createChat('bot', fromsms.message);
      this.messages.push(fromsms);
      setTimeout( ()=>{
        this.content.scrollToBottom();
      },300);
      this.compose = null;
    })
    .catch( error=> {

    })
  }

  chat(){
    let msg = {
      message:this.compose,
      from:'user'
    }
    this.messages.push(msg);
    setTimeout( ()=>{
      this.content.scrollToBottom();
    },300);

    let dataToSend = this.compose; 
    this.compose = null;

    this.createChat(this.userServices.getUserId(), msg.message);

    this.userServices.chat(dataToSend).then( data=> {
      let splitMsg = data['message'].split('@@@@');
      console.log(splitMsg);
      console.log(splitMsg[0]);
      let fromsms = {
        message : splitMsg[0],
        from : 'bot',
        action : data['action'],
        restaurants : data['restaurants']
      }
      if(data['action']){
        this.openForm = true;
        this.scrolltoBottom();
      }
      this.messages.push(fromsms);
      console.log(fromsms);
      this.createChat('bot', fromsms.message, fromsms.restaurants);
      
      setTimeout( ()=>{
        this.content.scrollToBottom();
      },300);
      this.compose = null;
    })
    .catch( error=> {

    })
  }

  scrolltoBottom(){
    setTimeout( ()=>{
        this.content.scrollToBottom();
      },300);
  }

  callCabService(){
    this.callNumber.callNumber("18001010101", true)
      .then(res => console.log('Launched dialer!', res))
      .catch(err => console.log('Error launching dialer', err));
  }

  fromModal(){
    this.fromStation = null;
    let modal = this.modalCtrl.create('StationSearchPage');
    modal.onDidDismiss( data=>{
      console.log(data)
      if(data.station)
        {this.fromStation = data.station.name;
                this.fromicsId = data.station.icsId;}
    });
    modal.present();
  }

  toModal(){
    this.toStation = null;
    let modal = this.modalCtrl.create('StationSearchPage');
    modal.onDidDismiss( data=>{
      console.log(data)
      if(data.station)
        {this.toStation = data.station.name;
                this.toicsId = data.station.icsId}
    });
    modal.present();
  }

  sendStations(){

    this.openForm = false;
    let query = this.fromicsId+'@@@'+this.fromStation+'@@@'+this.toicsId+'@@@'+this.toStation;
    this.userServices.rail_info(query).then( data=>{
      let splitMsg = data['message'].split('@@@@');
      let fromsms = {
        message : splitMsg[0],
        from : 'bot',
        action : data['action'],
        restaurants : data['restaurants']
      }
      if(data['action']){
        this.openForm = true;
        this.scrolltoBottom();
      }
      this.messages.push(fromsms);
      console.log(fromsms);
      this.createChat('bot', fromsms.message, fromsms.restaurants);
      
      setTimeout( ()=>{
        this.content.scrollToBottom();
      },300);
      this.compose = null;

    })
    .catch( error=>{
      console.log(error);
    })
  }

}

export const snapshotToArray = snapshot => {
  let returnArr = [];

  snapshot.forEach(childSnapshot => {
      let item = childSnapshot.val();
      item.key = childSnapshot.key;
      returnArr.push(item);
  });

  return returnArr;
};
